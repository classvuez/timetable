from django.apps import AppConfig


class ConsultationBookingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'consultation_booking'
